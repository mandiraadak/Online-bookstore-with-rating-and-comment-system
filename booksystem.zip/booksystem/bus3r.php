<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=3');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Statistics</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>Statistics</h2>
<h3>by McClave, Benson, Sincich</h3>
<p>This resource emphasizes statistical inference and sound decision-making through its extensive coverage of data collection and analysis. As in earlier editions, it helps develop statistical thinking and promotes inference assessment- from the vantage point of both the consumer and the producer. Includes new Three-phased Examples that contain three components: "problem," "solution," and "look back". </p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 350</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=3&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='bus3.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>