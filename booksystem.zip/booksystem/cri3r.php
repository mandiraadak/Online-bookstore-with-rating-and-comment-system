<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=9');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>The Silent Dead</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>The Silent Dead</h2>
<h3>by Claire Mcgowan</h3>
<ph>The Silent Dead (Detective Reiko Himekawa #1) When a body wrapped in a blue plastic tarp and tied up with twine is discovered near the bushes near a quiet suburban Tokyo neighborhood, Lt. Reiko Himekawa and her squad take the case.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 250</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=9&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='cri3.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>