<?php
session_start();
session_destroy();
header("Location: body1.php");
?>