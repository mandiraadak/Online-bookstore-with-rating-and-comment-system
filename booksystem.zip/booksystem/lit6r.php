<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=5');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>The Whistling School Boy</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>The Whistling School Boy</h2>
<h3>by Ruskin Bond</h3>
<p>A thoughtful new collection of school stories from India's most beloved storyteller. Here is a collection of stories about school life that will appeal to every kind of school-goer. These are incidents from the authors own life, when he was a shy, quiet boy in boarding school, who chose the library over the football field and was known as the best cook among the Boy Scouts.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 215</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=5&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='lit6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>