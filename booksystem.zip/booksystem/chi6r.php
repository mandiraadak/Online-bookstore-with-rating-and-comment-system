<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=12');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Caraval</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>Caraval</h2>
<h3>by Stephanie Garber</h3>
<p>When an invitation arrives from Legend himself, the mastermind creator of Caraval, beckoning the sisters to a mysterious island and offering them a place in the game, Tella forces Scarlett to abandon her plans of calculated safety in favor of an adventure. But it soon becomes clear that Legend has other ideas.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 275</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=12&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='chi6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>