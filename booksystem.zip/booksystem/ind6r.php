<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=16');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>The Indian War Of Independence 1857</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>The Indian War Of Independence 1857</h2>
<h3>by Veer Savarkar</h3>
<p>Savarkar attempted to look at the incidents of 1857 from the Indian point of view. A leading revolutionary himself, he was attracted and inspired by the burning zeal, the heroism, bravery, suffering and tragic fate of the leaders of 1857, and he decided to re-interpret the story and to relate it in full with the help of all the material available to him at the time. </p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 275</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=16&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='ind6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>