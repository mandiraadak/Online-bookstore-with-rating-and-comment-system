<?php
$con = mysql_connect("localhost","root","") or die(mysql_error());
$db = mysql_select_db("login1", $con) or die(mysql_error());
if (isset($_POST['submit'])){
 
   $name = $_POST['name'];
  $email = $_POST['email'];
  $user = $_POST['user'];
  $password = $_POST['password'];
  $psw_repeat = $_POST['psw_repeat'];

  if ($password == $psw_repeat) {
      $sql = mysql_query("Select * from login1 where user = '".$user."'");
      $numrows = mysql_num_rows($sql);
      if($numrows==0){

     $query = "insert into users(name,email,user,password) values('$name' , '$email', '$user', '$password')";

  if(mysql_query($query)){
    echo "You are successfully registered";
  }
  else
    echo "Failure";
}
else{
  echo "That username already exist";

}
  }
  else{
    echo "<script> alert('The two password do not match')</script>";
  }
  }
 ?>