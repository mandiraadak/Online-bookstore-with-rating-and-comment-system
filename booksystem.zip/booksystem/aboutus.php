  <?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'init.php';

  session_start();


?>  
<!DOCTYPE html>
<html>
<head>
  <title>About Us</title>
<script type="text/javascript" src="myScript.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<style>

body {
    background-image: url("bg3.jpg");
}

</style>
</head>
<body>
<iframe src="img.html" frameborder="0" width="500px"></iframe><iframe src="title.html" frameborder="0" width="500px"></iframe>
<div class="navbar">
  <ul class="ab"><li class="p"><a href="aboutus.php">About</a></li>
     <li class="p">
      <?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a>";
         } else {
          echo "<a href='javascript:alertIt();'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='aboutus.php';
}
</script>";
}
?>
  
</li>
    <li class="dropdown p">
         <a href="javascript:void(0)" class="dropbtn">
          <img src="logic.png" style="height: 23px;width: 23px;"> <?php
         if(isset($_SESSION['sess_user'])){
          $user = unserialize(serialize($_SESSION['sess_user']));
          echo "$user";
         }else
         echo "Account"; ?>
       </a>
              <div class="dropdown-content">
                
                       <?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'> Your Orders </a>";
         } else {
          echo "<a href='javascript:alertIt();'> Your Orders </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='aboutus.php';
}
</script>";
}
?>     
                 <?php
                if(!isset($_SESSION['sess_user'])){
                 echo "<button onclick='document.getElementById(\"id01\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Login</button>";
                 echo "<hr><h2 style='margin-left: 10px;'>Not a member</h2><button onclick='document.getElementById(\"id02\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Sign Up</button>";
               } else {
                 echo "<form action='logout.php'><button style='width:140px;margin-left: 8px; background-color: black;'>LogOut</button></form>";
               }
               ?>
              </div>
      </li>  
      <li class="r"><a href="body1.php"><img src="home.png" style="height: 23px;width: 23px;"> Home  </a></li>
      <li class="dropdown r">
      <a href="javascript:void(0)" class="dropbtn">Genre</a>
              <div class="dropdown-content">
                <a href="literature.php">Literature &amp Fiction</a>
                <a href="Romance.php">Romance</a>
                <a href="crime.php">Crime &amp Thriller</a>
                <a href="children.php">Children &amp Young Adult</a>
                <a href="scifi.php">Sci-Fi &amp Fantasy</a>
                <a href="business.php">Business &amp Economics</a>
                <a href="biography.php">Biographies &amp Memoirs</a>
                <a href="indian.php">Indian Writing</a>
                <a href="study.php">Study Aids &amp Exam Prep</a>
              
              </div>
              </li>
      
      <li class="r"><a href="newarrival.php">New Arrivals</span></a></li>
   </ul></div>
<img src="aboutus.png" height="25%" width="50%">
<iframe src="about.php" frameborder="0" style="height: 50%; width: 50%; margin-left: 40%;" ></iframe>
</body>
</html>