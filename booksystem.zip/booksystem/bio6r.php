<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=1');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Bossypants</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>Bossypants</h2>
<h3>by Tina Fey</h3>
<p>Bossypants is heartwarming memoir about growth and acceptance by comedian Tina Fey. The memoir recounts Fey’s childhood with clever insight and her trademark humor. Fey shows readers how she first started out in the industry and what lessons she has learned along the way. She also combines the overall narrative of her growth in comedy with seemingly random asides.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 275</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=1&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='bio6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>