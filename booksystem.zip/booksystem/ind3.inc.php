<?php

function setComments($conn) {
  if (isset($_POST['commentSubmit'])) {
      $user = $_POST['user'];  
      $date = $_POST['date'];
      $message = $_POST['message'];

      $sql = "INSERT INTO ind3 (user, date, message) VALUES ('$user', '$date', '$message')";
      $result = $conn -> query($sql);
        }
}

function getComments($conn) {
  $sql = "SELECT * FROM ind3";
  $result = $conn -> query($sql);
  while ($row = $result->fetch_assoc()) {
    $id = $row['user'];
  $sql2 = "SELECT * FROM users WHERE id='$id' ";
  $result2 = $conn->query($sql2);
  if($row2 = $result2->fetch_assoc()){
echo "<div class='comment-box' style='margin-left: 380px; width: 850px; padding: 20px; margin-bottom: 4px; background-color: #fff; border-radius: 4px; position: relative;'><p>";
      echo $row2['user']."<br>";
      echo $row['date']."<br>";
      echo nl2br($row['message']);
    
echo "</p>
    <form class='delete-form' method='POST' action='".deleteComments($conn)."'>
      <input type='hidden' name='eid' value='".$row['eid']."'>
      <button name='commentDelete' type='submit' style='margin-right: 25px;'>Delete</button>
      </form>
      <form class='edit-form' method='POST' action='editcomment.php'>
      <input type='hidden' name='eid' value='".$row['eid']."'>
      <input type='hidden' name='user' value='".$row['user']."'>
      <input type='hidden' name='date' value='".$row['date']."'>
      <input type='hidden' name='message' value='".$row['message']."'>
      <button style='margin-right: 20px;'>Edit</button>
      </form>
    </div>";

  }
  
    echo "<div class='comment-box' style='margin-left: 380px; width: 850px; padding: 20px; margin-bottom: 4px; background-color: #fff; border-radius: 4px; position: relative;'><p>";
      echo $row['user']."<br>";
      echo $row['date']."<br>";
      echo nl2br($row['message']);
    echo "</p>
    <form class='delete-form' method='POST' action='".deleteComments($conn)."'>
      <input type='hidden' name='eid' value='".$row['eid']."'>
      <button name='commentDelete' type='submit' style='margin-right: 25px;'>Delete</button>
      </form>
      <form class='edit-form' method='POST' action='editcomment.php'>
      <input type='hidden' name='eid' value='".$row['eid']."'>
      <input type='hidden' name='user' value='".$row['user']."'>
      <input type='hidden' name='date' value='".$row['date']."'>
      <input type='hidden' name='message' value='".$row['message']."'>
      <button style='margin-right: 20px;'>Edit</button>
      </form>
    </div>";
  }
}


function editComments($conn) {
  if (isset($_POST['commentSubmit'])) {
      $eid = $_POST['eid'];  
      $user = $_POST['user'];  
      $date = $_POST['date'];
      $message = $_POST['message'];

      $sql = "UPDATE comments SET message='$message' WHERE eid='$eid'";
      $result = $conn -> query($sql);
      header("Location: ind3.php");
        }
}

function deleteComments($conn){
  if (isset($_POST['commentDelete'])) {
      $eid = $_POST['eid'];  
      $sql = "DELETE FROM ind3 WHERE eid='$eid'";
      $result = $conn -> query($sql);
      header("Location: ind3.php");
        }
}

?>