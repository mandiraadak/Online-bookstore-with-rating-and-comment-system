<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=7');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>The Fault in Our Stars</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>The Fault in Our Star</h2>
<h3>by John Green</h3>
<p>The Fault In Our Stars is a fabulous book about a young teenage girl who has been diagnosed with lung cancer and attends a cancer support group.
Hazel is 16 and is reluctant to go to the support group, but she soon realises that it was a good idea. Hazel meets a young boy named Augustus Waters. He is charming and witty. Augustus has had osteosarcoma, a rare form of bone cancer, but has recently had the all clear.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 300</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=7&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='rom3.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>