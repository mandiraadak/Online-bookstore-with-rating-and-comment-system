  <?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'init.php';

  session_start();


?>  
<!DOCTYPE html>
<html>
<head>
  <title>Literature</title>
<script type="text/javascript" src="myScript.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<style>

body {
    background-image: url("bg3.jpg");
}

</style>
</head>
<body>
<iframe src="img.html" frameborder="0" width="500px"></iframe><iframe src="title.html" frameborder="0" width="500px"></iframe>
<div class="navbar">
  <ul class="ab"><li class="p"><a href="aboutus.php">About</a></li>
     <li class="p">
      <?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a>";
         } else {
          echo "<a href='javascript:alertIt();'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='crime.php';
}
</script>";
}
?>
  
</li>
    <li class="dropdown p">
         <a href="javascript:void(0)" class="dropbtn">
          <img src="logic.png" style="height: 23px;width: 23px;"> <?php
         if(isset($_SESSION['sess_user'])){
          $user = unserialize(serialize($_SESSION['sess_user']));
          echo "$user";
         }else
         echo "Account"; ?>
       </a>
              <div class="dropdown-content">
                
                       <?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'> Your Orders </a>";
         } else {
          echo "<a href='javascript:alertIt();'> Your Orders </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='crime.php';
}
</script>";
}
?>     
                 <?php
                if(!isset($_SESSION['sess_user'])){
                 echo "<button onclick='document.getElementById(\"id01\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Login</button>";
                 echo "<hr><h2 style='margin-left: 10px;'>Not a member</h2><button onclick='document.getElementById(\"id02\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Sign Up</button>";
               } else {
                 echo "<form action='logout.php'><button style='width:140px;margin-left: 8px; background-color: black;'>LogOut</button></form>";
               }
               ?>
              </div>
      </li>  
      <li class="r"><a href="body1.php"><img src="home.png" style="height: 23px;width: 23px;"> Home  </a></li>
     
      <li class="r"><a href="newarrival.php">New Arrivals</span></a></li>
   </ul></div>
   <div class="clearfix">
    <div class="column sidemenu">
      <ul><br><br>
     
        <li><a href="Romance.php">Romance</a></li>
        <li><a href="crime.php">Crime &amp Thriller</a></li>
        <li><a href="children.php">Children &amp Young Adult</a></li>
        <li><a href="scifi.php">Sci-Fi &amp Fantasy</a></li>
        <li><a href="business.php">Business &amp Economics</a></li>
        <li><a href="biography.php">Biographies &amp Memoirs</a></li>
        <li><a href="indian.php">Indian Writing</a></li>
        <li><a href="study.php">Study Aids &amp Exam Prep</a></li>
       
      </ul>
    </div>
<div style="margin-left: 50%; ">

<?php

require_once 'init.php';

 $article = null;

 if(isset($_GET['id'])){

 	 $id = (int)$_GET['id'];
 	
 	$article = $db->query("SELECT * FROM articles WHERE id ={$id}")->fetch_object();
 }
?>
	<?php if($article): ?>
		<div class="article">
			<?php echo '<h1>Rate this book!!!</h1>'; ?>
			<div class="article-rating"><h2>Rating: x/5</h2></div>
			<div class="article-rate">
			<h2>Rate this article:
			<?php foreach (range(1, 5) as $rating): ?>
				<a href="article4.php?article=<?php echo $article->id; ?>&rating=<?php echo $rating; ?>"><?php echo $rating; ?></a>
			<?php endforeach; ?></h2>
		</div>
</div>
<?php endif; ?> 

<?php

require_once 'init.php';

if(isset($_GET['article'], $_GET['rating'])){

	$article = (int)$_GET['article'];
	$rating = (int)$_GET['rating'];

	echo $rating;

	if (in_array($rating, [1, 2, 3, 4, 5])) {
		$exists = $db->query("SELECT id FROM articles WHERE id = {$article}")->num_rows ? true : false;

		if($exists){
			$db->query("INSERT INTO article_ratings (article, rating) VALUES ({$article}, {$rating})");
		}
	}
	header("Location: crime.php?id=" . $article);
}
?>
</div>
<div id="id01" class="modal">
  
 <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="login.jpg" style="height: 150px;width: 150px" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user" required><br>

      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>
        
      <button type="submit" name="submit" style="background-color: black;">Login</button>
      <!-- <input type="checkbox" checked="checked"> Remember me -->
      
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" id="r11" class="cancelbtn" style="background-color: red; height: 40px;">Cancel</button>
      <!-- <span class="psw">Forgot <a href="#">password?</a></span> -->
    </div>

  </form>
  </div>

<div id="id02" class="modal1">

 <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="login.jpg" style="height: 150px;width: 150px" alt="Avatar" class="avatar">
    </div>
    <div class="container1">
      <label><b>Name</b></label>
      <input type="text" name="name" placeholder="Enter Name">

      <label><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="email" required>

      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user" required>


      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>

      <label><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw_repeat" required>
      <input type="checkbox" checked="checked"> Remember me
      <p>By creating an account you agree to our <a href="#" style="color: red;">Terms & Privacy</a>.</p>

      <div class="clearfix1">
        <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn1 button1" style="background-color: red; height: 36px; padding-top: 8px;">Cancel</button>
        <button type="submit" class="signupbtn1" name="submit1" style="background-color: black;">Sign Up</button>
      </div>
    </div>
    </div>
    <?php
if(isset($_POST["submit1"])){
 $name = $_POST['name'];
  $email = $_POST['email'];
  $user = $_POST['user'];
  $password = $_POST['password'];
  $psw_repeat = $_POST['psw_repeat'];


  $con = mysql_connect('localhost','root','') or die(mysql_error());
  mysql_select_db('login1') or die("cannot select db");
  if($password == $psw_repeat){

  $query = mysql_query("select * from users where user='".$user."'");
  $numrows = mysql_num_rows($query);
  $query1 = mysql_query("select * from users where email='".$email."'");
  $numrows1 = mysql_num_rows($query1);
  if($numrows==0 && $numrows1==0)
  {
    $sql = "insert into users(name,email,user,password) values('$name' , '$email', '$user', '$password')";
    $result = mysql_query($sql);

    if($result){
      echo "<script> alert('Account successfully created'); </script>";
               }
  }
        elseif ($numrows==0){
        echo"<script> alert('Account with this email already exist'); </script>";
                      }
               elseif ($numrows1==0){
       echo"<script> alert('Account with this username already exist'); </script>";   
                      }
                          else {
      echo "<script> alert('Failure'); </script>";
              }
                                }
                                 else {
    echo "<script> alert('The two password donot match.'); </script>";
  }
}
?>
  </form>
</div>

</body>
</html>