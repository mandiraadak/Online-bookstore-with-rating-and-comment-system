<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=6');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Business Reports For Busy People</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>Business Reports For Busy People</h2>
<h3>by Greg Holden</h3>
<p>Reports that capture, analyze and explain the right data in a clear, concise format allow managers and decision makers to generate the best possible results. Business Reports for Busy People is a comprehensive guide filled with a wide range of samples and templates that can be customized to produce professional-looking, clear and concise reports for virtually any need.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 275</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=6&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='bus6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>