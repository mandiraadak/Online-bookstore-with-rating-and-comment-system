<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=13');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>As I Descended</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>As I Descended</h2>
<h3>by Robin Talley</h3>
<p>Maria Lyon and Lily Boiten are their school’s ultimate power couple—even if no one knows it but them.
Only one thing stands between them and their perfect future: campus superstar Delilah Dufrey.
Golden child Delilah is a legend at the exclusive Acheron Academy, and the presumptive winner of the distinguished Cawdor Kingsley Prize. She runs the school, and if she chose, she could blow up Maria and Lily’s whole world with a pointed look, or a carefully placed word.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 550</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=13&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='sci3.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>