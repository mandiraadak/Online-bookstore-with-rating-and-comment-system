
<?php
if(isset($_POST['submit'])){
  $user = $_POST['user'];
  $password = $_POST['password'];

  $con = mysql_connect('localhost','root','') or die(mysql_error());
  mysql_select_db('login1') or die('cannot select db');

  $query = mysql_query("select * from users where user='".$user."'and password='".$password."'");
  $numrows = mysql_num_rows($query);
  if($numrows!=0)
  {
    while($row = mysql_fetch_assoc($query))
    {
      $dbuser = $row['user'];
      $dbpassword = $row['password'];
    }

    if($user == $dbuser && $password ==$dbpassword){
      
      session_start();

      $_SESSION['sess_user'] = $user;
header('Location: '.$_SERVER['PHP_SELF']);
      echo "<script> alert('Successfully logged in!'); <script>";
    }

  }
  else {
    echo "<script> alert('Invalid username or password!'); </script>";

      }

    }
?>