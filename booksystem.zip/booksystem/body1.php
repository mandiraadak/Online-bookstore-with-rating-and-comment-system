  <?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 session_start();
?>     
  <!DOCTYPE html>
  <html>
  <head><title>Book Mania</title>

<script type="text/javascript" src="myScript.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">
  <style type="text/css">
    iframe{
      position: fixed;
    }
    html, body {
  height: 100%;
  overflow: auto;
}
  </style>

</head>
<body style="background-image:url('b.jpg'); background-attachment: fixed;background-size: 100% 100%;">

<iframe src="img.html" frameborder="0" width="650px"></iframe><iframe src="title.html" frameborder="0" width="500px" style="margin-left: 600px;"></iframe>
 
<iframe src="frame.html" height="100%" width="100%" style="margin-top: 270px; margin-left: 300px; border: 0; position:fixed; top:0; left:0; right:0; bottom:0;" frameborder="0"></iframe>

<div class="navbar" style="position: fixed; width: 100%; margin-top: 150px;">
  <ul class="ab"><li class="p"><a href="aboutus.php">About</a></li>
     <li class="p"><?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a>";
         } else {
          echo "<a href='javascript:alertIt();'><img src='cartic.png' style='height: 23px;width: 23px;'> Cart </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='body1.php';
}
</script>";
}
?>

           </li>
         
    <li class="dropdown p">
         <a href="javascript:void(0)" class="dropbtn"><img src="logic.png" style="height: 23px;width: 23px;"> <?php
         if(isset($_SESSION['sess_user'])){
          $user = unserialize(serialize($_SESSION['sess_user']));
          echo " $user";
         }else 
         echo "Account"; ?></a>
              <div class="dropdown-content">
                <?php if (isset($_SESSION['sess_user'])) {
         echo "<a href='cart1.php'> Your Orders </a>";
         } else {
          echo "<a href='javascript:alertIt();'> Your Orders </a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to view your cart!');
if (!answer)
window.location='body1.php';
}
</script>";
}
?>                
                <?php
                if(!isset($_SESSION['sess_user'])){
                 echo "<button onclick='document.getElementById(\"id01\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Login</button>";
                 echo "<hr><h2 style='margin-left: 10px;'>Not a member</h2><button onclick='document.getElementById(\"id02\").style.display=\"block\"' style='width:140px;margin-left: 8px; background-color: black;'>Sign Up</button>";
               } else {
                 echo "<form action='logout.php'><button style='width:140px;margin-left: 8px; background-color: black;'>LogOut</button></form>";
               }
               ?>
              </div>
      </li>  
      <li class="r"><a href="body1.php"><img src="home.png" style="height: 23px;width: 23px;"> Home</a></li>
      <!-- <li class="dropdown r">
      <a href="javascript:void(0)" class="dropbtn">Genre</a>
              <div class="dropdown-content">
                <a href="literature.php">Literature &amp Fiction</a>
                <a href="Romance.php">Romance</a>
                <a href="crime.php">Crime &amp Thriller</a>
                <a href="children.php">Children &amp Young Adult</a>
                <a href="scifi.php">Sci-Fi &amp Fantasy</a>
                <a href="business.php">Business &amp Economics</a>
                <a href="biography.php">Biographies &amp Memoirs</a>
                <a href="indian.php">Indian Writing</a>
                <a href="study.php">Study Aids &amp Exam Prep</a>
              
              </div>
              </li>
       --><li class="r"><a href="newarrival.php">New Arrivals</span></a></li>
   </ul></div>
   <div class="column sidemenu" style="position: fixed; margin-top: 200px;">
      <ul><br><br>
                <li><a href="crime.php" style="color: black;"><img src="cri.png" height="30px" width="30px">&nbsp &nbspCrime &amp Thriller</a></li>
        <li><a href="literature.php" style="color: black;"><img src="lit.png" height="30px" width="30px">&nbsp &nbspLiterature &amp Fiction</a></li>
        <li><a href="Romance.php" style="color: black;"><img src="rom.png" height="30px" width="30px">&nbsp &nbspRomance</a></li>

        <li><a href="children.php" style="color: black;"><img src="chi.png" height="30px" width="30px">&nbsp &nbspChildren &amp Young Adult</a></li>
        <li><a href="scifi.php" style="color: black;"><img src="sci.png" height="30px" width="30px">&nbsp &nbspSci-Fi &amp Fantasy</a></li>
       <li><a href="biography.php" style="color: black;"><img src="bio.png" height="30px" width="30px">&nbsp &nbspBiography</a></li>
        <li><a href="business.php" style="color: black;"><img src="bus.png" height="30px" width="30px">&nbsp &nbspBusiness &amp Economics</a></li>
        <li><a href="indian.php" style="color: black;"><img src="ind.png" height="30px" width="30px">&nbsp &nbspIndian Writing</a></li>
        <li><a href="study.php" style="color: black;"><img src="stu.png" height="30px" width="30px">&nbsp &nbspStudy Aids &amp Exam Prep</a></li>
       
      </ul>
    </div>
   
<div id="id01" class="modal">
  
 <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="login.jpg" style="height: 150px;width: 150px" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user" required><br>

      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>
        
      <button type="submit" name="submit" style="background-color: black;">Login</button>
      <!-- <input type="checkbox" checked="checked"> Remember me -->
      
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" id="r11" class="cancelbtn" style="background-color: red; height: 40px;">Cancel</button>
      <!-- <span class="psw">Forgot <a href="#">password?</a></span> -->
    </div>

  </form>
  </div>
<div id="id02" class="modal1">

 <form class="modal-content animate" action="" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="login.jpg" style="height: 150px;width: 150px" alt="Avatar" class="avatar">
    </div>
    <div class="container1">
      <label><b>Name</b></label>
      <input type="text" name="name" placeholder="Enter Name">

      <label><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="email" required>

      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="user" required>


      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>

      <label><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw_repeat" required>
      <p>By creating an account you agree to our <a href="#" style="color: red;">Terms & Privacy</a>.</p>

      <div class="clearfix1">
        <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn1 button1" style="background-color: red; height: 36px; padding-top: 8px;">Cancel</button>
        <button type="submit" class="signupbtn1" name="submit1" style="background-color: black;">Sign Up</button>
      </div>
    </div>
    <?php
if(isset($_POST["submit1"])){
 $name = $_POST['name'];
  $email = $_POST['email'];
  $user = $_POST['user'];
  $password = $_POST['password'];
  $psw_repeat = $_POST['psw_repeat'];
  $con = mysql_connect('localhost','root','') or die(mysql_error());
  mysql_select_db('login1') or die("cannot select db");
  

  if($password == $psw_repeat){

  $query = mysql_query("select * from users where user='".$user."'");
  $numrows = mysql_num_rows($query);
  $query1 = mysql_query("select * from users where email='".$email."'");
  $numrows1 = mysql_num_rows($query1);
  if($numrows==0 && $numrows1==0)
  {
    $sql = "insert into users(name,email,user,password) values('$name' , '$email', '$user', '$password')";
    $result = mysql_query($sql);

    if($result){
      echo "<script> alert('Account successfully created'); </script>";
               }
  }
        elseif ($numrows==0){
        echo"<script> alert('Account with this email already exist'); </script>";
                      }
               elseif ($numrows1==0){
       echo"<script> alert('Account with this username already exist'); </script>";   
                      }
                          else {
      echo "<script> alert('Failure'); </script>";
              }
                                }
                                 else {
    echo "<script> alert('The two password donot match.'); </script>";
  }
}
?>
  </form>
  

 </div>

</body>
</html>


