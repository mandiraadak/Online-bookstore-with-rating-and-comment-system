<?php
 date_default_timezone_set('Asia/kolkata');
 include 'login.php';
 include 'dba.php';
 include 'comments.inc.php';
 include 'init.php';
 include 'item.php';
 $result = mysqli_query($db, 'SELECT * FROM articles WHERE id=18');
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Parisar Abhyas</title>
	<style type="text/css">
		a{
			text-decoration: none;
			color: white;
		}
	</style>
</head>
<body>
	
<h2>Parisar Abhyas</h2>
<h3>Third Standard</h3>
<p>This book is related to environmental studies of marathi medium of third standard. Publication : Balbharti. Free DVDs available with the book.</p>
<form method="post">
	<table>
		<tr><th><h3>Price:</h3></th><td><h3>Rs 105</h3></td>
		<tr><td><?php 
		if (isset($_SESSION['sess_user'])) {
			echo "<button type=submit style='height:40px; width: 75px; background-color:black; font-size:25px; border:none; cursor:pointer;'><a href='cart.php?id=18&action=add'>Buy</a></button>";
		}
		else {
			echo "<button style='height:40px; width: 75px; background-color:black; font-size: 25px; border:none; cursor: pointer; decoration: none;'><a href='javascript:alertIt();'>Buy</a></button><script type='text/javascript'>
            function alertIt(){
var answer = confirm ('Please login to buy this book!');
if (!answer)
window.location='stu6.php';
}
</script>";
		}
		?>
		</td>
</tr>
</form>
</body>
</html>