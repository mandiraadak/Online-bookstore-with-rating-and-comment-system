<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<p style="font-size: 20px; font-style: Arial;"><strong>&nbsp &nbsp
Book Mania is an online shopping site which gives an unique experience to our users. Started just 2 years ago, the aim was to provide an effective shopping to everyone. This site gives low cost shopping and exchange offers. Book Mania aims to seperate you from daily chaos of hustle and bustle of shopping. Do visit our site!</strong></p>


</body>
</html>